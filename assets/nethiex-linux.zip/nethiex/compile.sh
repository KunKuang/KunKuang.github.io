#!/bin/bash

# Code only tested in a linux 64bit environment.
# g++ -std=c++14 -Wall -Wextra -O2 ncrp.cpp -o ncrp -lblas -ldlib
g++ -std=c++14 -Wall -Wextra -O2 ncrp.cpp -o ncrp
